# Kestrel VPN — Projet Android APK Universel (54 Pays Africains · Go Illimités)

Ce dépôt contient le code source complet Kotlin / Android VpnService prêt à compiler en **APK universel** (`arm64-v8a`, `armeabi-v7a`, `x86`, `x86_64`) compatible Android 7.0 à Android 15 (API 24–35).

## Fonctionnalités incluses
- **54 pays africains avec indicatifs (+20 à +291) et opérateurs mobiles** intégrés dans `app/src/main/assets/servers.json`.
- **Quota Go illimité** sur tous les profils sans bridage de volume.
- **Connexion directe par adresse IP passerelle** (`194.36.144.149:51820`).
- **Profil actif pré-embarqué** : Tanzanie (+255) · Vodacom.
- **Kill Switch & Split Tunneling** natifs via `VpnService.Builder.addDisallowedApplication()`.

## Méthode 1 : Compiler l'APK dans Android Studio
1. Ouvrez ce dossier dans **Android Studio**.
2. Exécutez :
   ```bash
   ./gradlew assembleUniversalRelease
   ```

## Méthode 2 : Compiler l'APK automatiquement dans le cloud (GitHub Actions, sans PC)
1. Créez un dépôt sur GitHub et déposez-y le contenu de ce dossier.
2. Ouvrez l'onglet **Actions** → le workflow `.github/workflows/build-apk.yml` installe Android SDK + Gradle 8.9 et compile automatiquement `app-universal-debug.apk`.
3. Téléchargez l'artefact **kestrel-vpn-universal-apk** prêt à installer sur tout téléphone Android.
