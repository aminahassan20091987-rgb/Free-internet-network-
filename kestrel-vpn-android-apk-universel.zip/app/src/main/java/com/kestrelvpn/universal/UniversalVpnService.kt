package com.kestrelvpn.universal

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.ByteArrayInputStream

class UniversalVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private var backend: GoBackend? = null

    private val activeTunnel = object : Tunnel {
        override fun getName(): String = "kestrel_tun0"
        override fun onStateChange(newState: Tunnel.State) {
            // Mise à jour d'état du tunnel
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_DISCONNECT) {
            stopTunnel()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())
        val rawConfig = intent?.getStringExtra(EXTRA_WG_CONFIG)
            ?: assets.open("kestrel_default.conf").bufferedReader().use { it.readText() }

        startWireGuardTunnel(rawConfig)
        return START_STICKY
    }

    private fun startWireGuardTunnel(rawConfig: String) {
        try {
            val goBackend = backend ?: GoBackend(applicationContext).also { backend = it }
            val parsed = Config.parse(ByteArrayInputStream(rawConfig.toByteArray()))
            goBackend.setState(activeTunnel, Tunnel.State.UP, parsed)
        } catch (_: Exception) {
            val builder = Builder()
                .setSession("Kestrel VPN")
                .addAddress("10.8.0.2", 32)
                .setMtu(1420)

            val dnsServers = listOf("1.1.1.1", "1.0.0.1")
            dnsServers.forEach { dns -> builder.addDnsServer(dns) }

            builder.addRoute("0.0.0.0", 0)
            builder.setBlocking(true)

            val excluded = listOf("com.orange.orangemoney", "com.wave.personal")
            excluded.forEach { pkg ->
                runCatching { builder.addDisallowedApplication(pkg) }
            }

            vpnInterface = builder.establish()
        }
    }

    private fun stopTunnel() {
        runCatching { backend?.setState(activeTunnel, Tunnel.State.DOWN, null) }
        runCatching { vpnInterface?.close() }
        vpnInterface = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val channelId = "kestrel_vpn_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Tunnel VPN Kestrel",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("Kestrel VPN · Go illimités")
            .setContentText("Tanzanie (+255) · Vodacom")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_DISCONNECT = "com.kestrelvpn.universal.DISCONNECT"
        const val EXTRA_WG_CONFIG = "wg_config"
        private const val NOTIFICATION_ID = 1042
    }
}
