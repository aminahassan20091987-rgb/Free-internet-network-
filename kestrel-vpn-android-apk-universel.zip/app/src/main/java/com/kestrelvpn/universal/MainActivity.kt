package com.kestrelvpn.universal

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var isConnected = false
    private lateinit var statusLabel: TextView
    private lateinit var toggleButton: Button

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            launchVpnService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(64, 128, 64, 64)
        }

        val title = TextView(this).apply {
            text = "Kestrel VPN · Go Illimités"
            textSize = 24f
        }

        statusLabel = TextView(this).apply {
            text = "Prêt — Tanzanie (+255) · Vodacom"
            textSize = 15f
            setPadding(0, 24, 0, 48)
        }

        toggleButton = Button(this).apply {
            text = "Activer le VPN"
            setOnClickListener {
                if (isConnected) {
                    val stopIntent = Intent(this@MainActivity, UniversalVpnService::class.java).apply {
                        action = UniversalVpnService.ACTION_DISCONNECT
                    }
                    startService(stopIntent)
                    isConnected = false
                    text = "Activer le VPN"
                    statusLabel.text = "Déconnecté"
                } else {
                    val prepareIntent = VpnService.prepare(this@MainActivity)
                    if (prepareIntent != null) {
                        vpnPermissionLauncher.launch(prepareIntent)
                    } else {
                        launchVpnService()
                    }
                }
            }
        }

        root.addView(title)
        root.addView(statusLabel)
        root.addView(toggleButton)
        setContentView(root)
    }

    private fun launchVpnService() {
        val intent = Intent(this, UniversalVpnService::class.java)
        startForegroundService(intent)
        isConnected = true
        toggleButton.text = "Déconnecter"
        statusLabel.text = "Tunnel actif · Tanzanie (+255) · Vodacom"
    }
}
