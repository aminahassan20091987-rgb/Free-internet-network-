// à ajouter dans auth.js
const API_OTP = '/api/auth/';
async function postRaw(path, body) { /* identique à post() mais avec API_OTP */ }
/* EarnMoney FBU — helpers partagés des pages d’auth.
   Côté serveur : le refresh token doit être posé en cookie HttpOnly + Secure + SameSite=Strict ;
   seul l’access token (courte durée) est renvoyé dans le JSON. */
(function () {
  const API = '/api/auth/';
  const REFERRAL_REQUIRED = true; // false = code parrain facultatif à l’inscription

  const q = (k) => new URLSearchParams(location.search).get(k) || '';

  // Identifiant d’appareil, envoyé au serveur pour la règle « 1 compte / appareil ».
  function deviceId() {
    try {
      let id = localStorage.getItem('fbu_device');
      if (!id) { id = crypto.randomUUID(); localStorage.setItem('fbu_device', id); }
      return id;
    } catch (e) { return 'unknown'; }
  }

  async function post(endpoint, body) {
    try {
      const res = await fetch(API + endpoint, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...body, device_id: deviceId() })
      });
      const data = await res.json().catch(() => ({}));
      return { ok: res.ok, status: res.status, data };
    } catch (e) {
      return { ok: false, status: 0, data: { message: 'Connexion impossible. Vérifie ton réseau.' } };
    }
  }

  let timer;
  function toast(msg, type = 'err') {
    let el = document.getElementById('toast');
    if (!el) { el = document.createElement('div'); el.id = 'toast'; el.setAttribute('role', 'status'); document.body.appendChild(el); }
    el.className = 'toast ' + type;
    el.textContent = msg;
    requestAnimationFrame(() => el.classList.add('show'));
    clearTimeout(timer);
    timer = setTimeout(() => el.classList.remove('show'), 3400);
  }

  function shake(el) {
    el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake');
    if (navigator.vibrate) navigator.vibrate(60);
  }

  const normPhone = (v) => v.replace(/[\s\-().]/g, '');
  const isPhone = (v) => /^\+\d{8,15}$/.test(normPhone(v));
  const isEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim());

  function saveSession(d) {
    try { sessionStorage.setItem('fbu_token', d.access_token); } catch (e) {}
  }

  window.Auth = { REFERRAL_REQUIRED, q, post, toast, shake, normPhone, isPhone, isEmail, saveSession };
})();
